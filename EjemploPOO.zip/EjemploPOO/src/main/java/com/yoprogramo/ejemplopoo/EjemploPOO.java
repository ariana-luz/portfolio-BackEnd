/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */
package com.yoprogramo.ejemplopoo;

/**
 *
 * @author Propietario
 */
public class EjemploPOO {

    public static void main(String[] args) {
        Vehiculo vehiculo1 = new Vehiculo(56879, 4, "Renault", "Indefinido");
        Auto auto2 = new Auto(1, "AA111JO", 5, "rojo", true, 65324, 4, "Volkswagen", "Gol Trend");
        Moto moto1 = new Moto(125, 15698, 2, "Yamaha", "ZR125");
        Camion camion1 = new Camion(6, true, 698755, 6, "Mercedes", "Un modelo");

        Vehiculo vector[] = new Vehiculo[4];
        vector[0] = vehiculo1;
        vector[1] = auto2;
        vector[2] = moto1;
        vector[3] = camion1;
        
        for (int i=0; i<4; i++) {
            System.out.println("Registro N° " + i + vector[i].getMarca());
        }
    }
}
