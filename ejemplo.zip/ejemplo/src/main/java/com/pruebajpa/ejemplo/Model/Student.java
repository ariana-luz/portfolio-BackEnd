package com.pruebajpa.ejemplo.Model;

public class Student {
    
}
