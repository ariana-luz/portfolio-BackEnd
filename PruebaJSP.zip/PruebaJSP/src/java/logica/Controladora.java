package logica;

import java.util.List;
import persistencia.ControladoraPersistencia;

public class Controladora {

    ControladoraPersistencia controlPersis = new ControladoraPersistencia();

    public void crearPersona(Persona per) {
        controlPersis.crearPersona(per);
    }

    public void eliminarPersona(int id) {
        controlPersis.eliminarPersona(id);
    }

    public void eliminarPersona(Persona per) {
        controlPersis.eliminarPersona(per);
    }

    public void editarPersona(int id) {
        controlPersis.editarPersona(id);
    }

    public void editarPersona(Persona per) {
        controlPersis.editarPersona(per);
    }

    public List<Persona> traerPersonas() {
        return controlPersis.traerPersonas();
    }

    public void editarPersona(String id_editar) {
        //throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
